r=20;
r2=r*r;

N=20;
X1=[1:1:(N)];
X2=[1:1:(N)];
[X1grid,X2grid]=meshgrid(X1,X2);
Gauss=exp(-((X1grid-(N)/2).*(X1grid-(N)/2)+(X2grid-(N)/2).*(X2grid-(N)/2))/0.5);
I1=fftshift(Gauss);



I2=zeros(r,r);
I2(10-2:10+2,10-2:10+2)=1;

I3=real(ifft2(conj(fft2(I1)).*fft2(I2)))

CircI=zeros(r2,r,r);
for i = 1:r 
    temp1 = circshift(I1, i-1, 1);
    for j = 1:r
        temp2 = circshift(temp1, j-1, 2);
        CircI((j-1)*r + i, :, :) = temp2;
    end
end

for i = 1:r  
    for j = 1:r      
        temp2= CircI((j-1)*r + i, :, :) ;
        I4(i,j)=temp2(:).'*I2(:);
    end
end
I4-I3