clc;
clear all;
I=imread('lena.png');
R=rgb2hsv(I);
I=I(1:2:end,1:2:end,:);


PaddingI=zeros(100,100,3);
PaddingI(50-15:50+15,50-15:50+15,:)=I(128-15:128+15,128-15:128+15,:);
figure;
imshow(uint8(PaddingI),[]);
hold on;

X=double(PaddingI(:,:,1));
x=X(:);


Xc=double(PaddingI(:,:,:));
XTemp=circshift(Xc,30,1);
Z=circshift(XTemp,30,2);
figure;
imshow(uint8(Z),[]);
hold on;
Z=Z(:,:,1);
z=Z(:);

%=================================Ƶ�����===================================
N=100;
X1=[1:1:(N)];
X2=[1:1:(N)];
[X1grid,X2grid]=meshgrid(X1,X2);
Gauss=exp(-((X1grid-(N)/2).*(X1grid-(N)/2)+(X2grid-(N)/2).*(X2grid-(N)/2))/5);
figure;
imagesc(Gauss);
xlabel('Horizontal coordinates');
ylabel('longitudinal coordinates');
set(gca,'FontWeight','bold','fontweight','b');
hold on;
tic;
y_v=Gauss(:);
lambda=0.01;
Hf=conj(fft(x)).*fft(y_v)./(abs(fft(x)).^2+lambda);
r2=real(ifft(fft(double(z)).*Hf));
R2=reshape(r2,[100,100]);

figure;
imagesc(R2);
hold on;
toc;
%=================================�������1��Bar��=====================================
tic
C_xt=zeros(size(x,1),size(x,1));
C_xt(1,:)=x.';
for i=1:size(x,1)-1
      C_xt(i+1,:)=circshift(x,i).';     
end

C_zt=zeros(size(z,1),size(z,1));
C_zt(1,:)=z.';
for i=1:size(z,1)-1
      C_zt(i+1,:)=circshift(z,i).';     
end

h=inv(C_xt.'*C_xt+lambda)*C_xt.'*y_v(:);
R1=reshape(C_zt*h,[100,100]);
figure
imagesc(R1);
hold on;
toc
% %=================================�������2=====================================
tic
h=inv(C_xt.'*C_xt+lambda)*C_xt.'*y_v(:);
C_ht=zeros(size(h,1),size(h,1));
C_ht(1,:)=h.';
for i=1:size(h,1)-1
      C_ht(i+1,:)=circshift(h,i).';     
end
R3=reshape(C_ht*z,[100,100]);
figure
imagesc(R3);
hold on;
toc

